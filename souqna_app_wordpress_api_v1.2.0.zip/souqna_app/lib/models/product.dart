class Product {
  final String id;
  final String name;
  final String category;
  final double basePrice; // السعر اللي التاجر حدده
  final double maxSuggestedPrice; // أعلى سعر بيع مسموح للمسوق
  final String imageEmoji;
  final String? imageUrl;
  final int stock;

  const Product({
    required this.id,
    required this.name,
    required this.category,
    required this.basePrice,
    required this.maxSuggestedPrice,
    required this.imageEmoji,
    this.imageUrl,
    required this.stock,
  });
}

class OrderItem {
  final Product product;
  final int quantity;
  final double sellPrice; // السعر اللي هيتباع بيه (ممكن يكون سعر مسوق)

  const OrderItem({
    required this.product,
    required this.quantity,
    required this.sellPrice,
  });

  double get total => sellPrice * quantity;
}


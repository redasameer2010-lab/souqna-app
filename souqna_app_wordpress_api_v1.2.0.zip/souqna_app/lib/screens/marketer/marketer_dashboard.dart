import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../models/product.dart';
import '../../services/api_service.dart';
import 'select_product_screen.dart';

class MarketerDashboard extends StatefulWidget {
  const MarketerDashboard({super.key});

  @override
  State<MarketerDashboard> createState() => _MarketerDashboardState();
}

class _MarketerDashboardState extends State<MarketerDashboard> {
  late Future<Map<String, dynamic>> _dataFuture;

  @override
  void initState() {
    super.initState();
    _dataFuture = ApiService.instance.marketerDashboard();
  }

  void _refresh() => setState(() => _dataFuture = ApiService.instance.marketerDashboard());

  Product _product(Map<String, dynamic> row) {
    final price = (row['price'] as num?)?.toDouble() ?? 0;
    return Product(
      id: '${row['id']}',
      name: row['name']?.toString() ?? '',
      category: '',
      basePrice: (row['base_price'] as num?)?.toDouble() ?? price,
      maxSuggestedPrice: (row['max_suggested_price'] as num?)?.toDouble() ?? price,
      imageEmoji: '🛍️',
      imageUrl: row['image']?.toString(),
      stock: (row['stock_quantity'] as num?)?.toInt() ?? 0,
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('لوحة المسوق')),
    body: FutureBuilder<Map<String, dynamic>>(
      future: _dataFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: AppColors.primary));
        }
        if (snapshot.hasError) return Center(child: Text('تعذر تحميل لوحة المسوق\n${snapshot.error}',
            textAlign: TextAlign.center));
        final data = snapshot.data ?? {};
        final total = (data['total_commission'] as num?)?.toDouble() ?? 0;
        final rows = (data['products'] as List? ?? []).map((e) => _product(Map<String,dynamic>.from(e))).toList();
        return RefreshIndicator(
          onRefresh: () async => _refresh(),
          child: ListView(padding: const EdgeInsets.all(16), children: [
            Container(padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(16)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('إجمالي العمولات المحققة', style: TextStyle(color: Colors.white70, fontSize: 13)),
                const SizedBox(height: 6),
                Text('${total.toStringAsFixed(0)} ر.س',
                    style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
              ])),
            const SizedBox(height: 20),
            const Text('منتجات متاحة للتسويق',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.navy)),
            const SizedBox(height: 8),
            ...rows.map((p) => ListTile(
              title: Text(p.name),
              subtitle: Text('سعر التاجر: ${p.basePrice.toStringAsFixed(0)} ر.س'),
              trailing: TextButton(onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => SelectProductScreen(product: p))), child: const Text('حدد سعرك')),
            )),
          ]),
        );
      },
    ),
  );
}

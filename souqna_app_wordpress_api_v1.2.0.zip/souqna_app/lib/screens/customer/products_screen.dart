import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../models/product.dart';
import '../../services/api_service.dart';
import 'product_detail_screen.dart';
import 'cart_screen.dart';
import '../../services/cart_service.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  late Future<List<Product>> _productsFuture;

  @override
  void initState() {
    super.initState();
    _productsFuture = _fetchProducts();
  }

  Future<List<Product>> _fetchProducts() async {
    final rows = await ApiService.instance.products(perPage: 50);
    return rows.map((row) {
      final price = (row['price'] as num?)?.toDouble() ?? 0;
      final regular = (row['regular_price'] as num?)?.toDouble() ?? price;
      final stockQty = (row['stock_quantity'] as num?)?.toInt() ?? 0;
      final image = row['image']?.toString();
      final categories = (row['categories'] as List?) ?? [];
      final category = categories.isNotEmpty
          ? ((categories.first as Map)['name']?.toString() ?? '')
          : '';
      return Product(
        id: '${row['id']}',
        name: row['name']?.toString() ?? '',
        category: category,
        basePrice: price,
        maxSuggestedPrice: regular > price ? regular : price,
        imageEmoji: image ?? '🛍️',
        imageUrl: image,
        stock: stockQty,
      );
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المتجر'),
        actions: [
          ValueListenableBuilder(
            valueListenable: CartService.instance.items,
            builder: (context, items, _) => Stack(
              alignment: Alignment.center,
              children: [
                IconButton(
                  icon: const Icon(Icons.shopping_cart_outlined),
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const CartScreen())),
                ),
                if (items.isNotEmpty)
                  Positioned(
                    top: 8,
                    right: 8,
                    child: CircleAvatar(
                      radius: 8,
                      backgroundColor: AppColors.gold,
                      child: Text('${items.length}',
                          style: const TextStyle(fontSize: 10, color: Colors.white)),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
      body: FutureBuilder<List<Product>>(
        future: _productsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: AppColors.primary));
          }
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'تعذر تحميل المنتجات، تأكد من اتصالك بالإنترنت',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.textSecondary),
                ),
              ),
            );
          }
          final products = snapshot.data ?? [];
          if (products.isEmpty) {
            return const Center(
              child: Text('لا توجد منتجات بعد', style: TextStyle(color: AppColors.textSecondary)),
            );
          }
          return GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 0.72,
            ),
            itemCount: products.length,
            itemBuilder: (context, index) => _ProductCard(product: products[index]),
          );
        },
      ),
    );
  }
}

class _ProductCard extends StatelessWidget {
  final Product product;
  const _ProductCard({required this.product});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ProductDetailScreen(product: product)),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.bgLight, width: 2),
        ),
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Center(
                child: product.imageUrl != null && product.imageUrl!.isNotEmpty
                    ? Image.network(product.imageUrl!, fit: BoxFit.contain,
                        errorBuilder: (_, __, ___) => const Text('🛍️', style: TextStyle(fontSize: 48)))
                    : const Text('🛍️', style: TextStyle(fontSize: 48)),
              ),
            ),
            Text(product.name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.navy)),
            const SizedBox(height: 4),
            Text('${product.basePrice.toStringAsFixed(0)} ر.س',
                style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../services/api_service.dart';

class OrderDetailsScreen extends StatefulWidget {
  final Map<String, dynamic> order;
  const OrderDetailsScreen({super.key, required this.order});
  @override State<OrderDetailsScreen> createState() => _OrderDetailsScreenState();
}

class _OrderDetailsScreenState extends State<OrderDetailsScreen> {
  bool _loading = false;
  String? _error;

  Future<void> _action(String status) async {
    setState(() { _loading = true; _error = null; });
    try {
      final id = int.tryParse('${widget.order['id']}');
      if (id == null) throw Exception('رقم الطلب غير صحيح');
      if (status == 'claim') {
        await ApiService.instance.courierClaim(id);
      } else {
        await ApiService.instance.courierStatus(id, status);
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(
        status == 'claim' ? 'تم استلام الطلب' : 'تم تحديث حالة الطلب')));
      Navigator.pop(context);
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final order = widget.order;
    final items = (order['items'] as List? ?? []);
    final status = order['status']?.toString() ?? 'pending';
    final address = order['shipping_address']?['address_1']?.toString()
        ?? order['billing']?['address_1']?.toString() ?? 'غير محدد';
    return Scaffold(
      appBar: AppBar(title: Text('طلب #${order['id']}')),
      body: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('العنوان', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
        const SizedBox(height: 4),
        Text(address, style: const TextStyle(color: AppColors.navy, fontWeight: FontWeight.w700, fontSize: 16)),
        const SizedBox(height: 20),
        const Text('محتويات الطلب', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.navy)),
        const SizedBox(height: 8),
        ...items.map((item) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [Expanded(child: Text('${item['name'] ?? 'منتج'} × ${item['quantity'] ?? 1}')),
            Text('${((item['total'] ?? 0) as num).toStringAsFixed(0)} ر.س')],
        ))),
        const Divider(height: 32),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('المبلغ المطلوب تحصيله', style: TextStyle(color: AppColors.navy)),
          Text('${((order['total'] ?? 0) as num).toStringAsFixed(0)} ر.س',
            style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary, fontSize: 18)),
        ]),
        if (_error != null) Padding(padding: const EdgeInsets.only(top: 12),
          child: Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 13))),
        const Spacer(),
        if (status == 'pending' && (order['courier_id'] ?? 0) == 0)
          _button('استلام الطلب', () => _action('claim'))
        else if (status == 'preparing')
          _button('الطلب في الطريق', () => _action('out_for_delivery'))
        else if (status == 'out_for_delivery')
          _button('تأكيد التسليم والتحصيل', () => _action('delivered'))
        else if (status == 'delivered')
          const Padding(padding: EdgeInsets.symmetric(vertical: 12),
            child: Text('تم تسليم هذا الطلب بالفعل', textAlign: TextAlign.center)),
      ])),
    );
  }

  Widget _button(String text, VoidCallback onPressed) => SizedBox(width: double.infinity,
    child: ElevatedButton(onPressed: _loading ? null : onPressed,
      child: _loading ? const SizedBox(width: 20,height:20,child:CircularProgressIndicator(strokeWidth:2,color:Colors.white)) : Text(text)));
}

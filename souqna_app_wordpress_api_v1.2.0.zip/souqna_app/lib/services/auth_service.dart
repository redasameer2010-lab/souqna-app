import 'api_service.dart';

class ApiUser {
  final int id;
  final String username;
  final String email;
  final String firstName;
  final String lastName;
  final String displayName;
  final List<String> roles;

  ApiUser.fromJson(Map<String, dynamic> json)
      : id = int.tryParse('${json['id']}') ?? 0,
        username = json['username']?.toString() ?? '',
        email = json['email']?.toString() ?? '',
        firstName = json['first_name']?.toString() ?? '',
        lastName = json['last_name']?.toString() ?? '',
        displayName = json['display_name']?.toString() ?? '',
        roles = (json['roles'] as List? ?? []).map((e) => e.toString()).toList();
}

class AuthService {
  AuthService._();

  static ApiService get _api => ApiService.instance;
  static ApiUser? _user;

  static ApiUser? get currentUser => _user;
  static bool get isLoggedIn => _api.isAuthenticated;

  static Future<void> init() async {
    await _api.init();
    if (_api.isAuthenticated) {
      try {
        final data = await _api.me();
        _user = ApiUser.fromJson(Map<String, dynamic>.from(data['user'] as Map));
      } catch (_) {
        await _api.logout();
        _user = null;
      }
    }
  }

  static Future<void> signUp({
    required String email,
    required String password,
    required String fullName,
    required String role,
    String? phone,
  }) async {
    final data = await _api.register(
      email: email,
      password: password,
      fullName: fullName,
      phone: phone,
      role: role,
    );
    _user = ApiUser.fromJson(Map<String, dynamic>.from(data['user'] as Map));
  }

  static Future<void> signIn({
    required String email,
    required String password,
  }) async {
    final data = await _api.login(email, password);
    _user = ApiUser.fromJson(Map<String, dynamic>.from(data['user'] as Map));
  }

  static Future<void> signOut() async {
    await _api.logout();
    _user = null;
  }

  static String? getCurrentUserRoleSync() {
    final roles = _user?.roles ?? [];
    if (roles.contains('administrator')) return 'merchant';
    if (roles.contains('seller') || roles.contains('vendor') || roles.contains('dokan_vendor')) return 'merchant';
    if (roles.contains('marketer')) return 'marketer';
    if (roles.contains('courier')) return 'courier';
    return 'customer';
  }

  static Future<String?> getCurrentUserRole() async {
    if (_user == null && _api.isAuthenticated) {
      try {
        final data = await _api.me();
        _user = ApiUser.fromJson(Map<String, dynamic>.from(data['user'] as Map));
      } catch (_) {}
    }
    return getCurrentUserRoleSync();
  }
}

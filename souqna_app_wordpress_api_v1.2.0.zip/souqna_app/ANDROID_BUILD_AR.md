# تحويل تطبيق سوقنا إلى APK Android

المشروع الآن متصل مباشرة بـ WordPress API:
`https://sauqna.com/wp-json/sooqna/v1`

## أسهل طريقة بدون تثبيت Flutter على جهازك

استخدم GitHub Actions:

1. أنشئ Repository جديد على GitHub.
2. ارفع محتويات مجلد `souqna_app` إلى المستودع.
3. افتح تبويب **Actions**.
4. اختر **Build Souqna APK**.
5. اضغط **Run workflow**.
6. بعد انتهاء البناء افتح نتيجة التشغيل ثم **Artifacts**.
7. نزّل `souqna-release-apk` وستجد داخله `app-release.apk`.

لا توجد مفاتيح Supabase مطلوبة لهذا البناء.

## البناء على كمبيوتر عليه Flutter

```bash
flutter create . --platforms=android --project-name souqna_app --org com.alkyanmedia
flutter pub get
flutter build apk --release
```

الناتج:
`build/app/outputs/flutter-apk/app-release.apk`

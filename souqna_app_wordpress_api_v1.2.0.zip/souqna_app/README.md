# سوقنا - Souqna App

## تم ربط التطبيق بـ WordPress API

التطبيق يستخدم الآن REST API على `https://sauqna.com/wp-json/sooqna/v1` بدل Supabase. لا تضع مفاتيح WooCommerce داخل التطبيق؛ المصادقة تتم عبر Bearer Token محفوظ في Android Secure Storage.

### API المطلوبة
- `POST /auth/register`
- `POST /auth/login`
- `POST /auth/logout`
- `GET /me`
- `GET /categories`
- `GET /products`
- `GET /products/{id}`
- `GET /orders`
- `POST /orders`
- `GET /orders/{id}`
- `GET/POST /merchant/products`
- `GET /merchant/orders`
- `GET /marketer/dashboard`
- `GET /courier/orders`
- `POST /courier/orders/{id}/claim`
- `POST /courier/orders/{id}/status`


تطبيق Flutter لماركت بليس "سوقنا" مع باك إند حقيقي على WordPress/WooCommerce عبر REST API.

## مهم قبل البناء
التطبيق متصل الآن بـ WordPress/WooCommerce عبر REST API، ولا يحتاج مفاتيح Supabase للبناء.

## الخطوة 1: WordPress API

1. افتح https://supabase.com وسجّل حساب، وأنشئ مشروع جديد (اختر منطقة قريبة منك زي Frankfurt أو Singapore).
2. من القائمة الجانبية روح على **SQL Editor**، وانسخ محتوى ملف `supabase/schema.sql` الموجود في المشروع، وشغّله بالكامل (Run).
   - ده هيعمل كل الجداول (profiles, products, orders, order_items, commissions) مع صلاحيات الأمان (RLS) وتريجر إنشاء البروفايل التلقائي.
3. روح على **Project Settings > API** وهتلاقي:
   - `Project URL`
   - `anon public key`
4. افتح `lib/services/supabase_service.dart` واستبدل القيمتين:
   ```dart
   static const String url = 'https://YOUR_PROJECT_ID.supabase.co';
   static const String anonKey = 'YOUR_ANON_PUBLIC_KEY';
   ```

## الخطوة 2: تثبيت Flutter وتشغيل المشروع

```bash
cd souqna_app
flutter pub get
flutter run
```

## الخطوة 3: بناء APK وتركيبه على جوالك

1. فعّل **خيارات المطور** و **USB Debugging** على جوالك.
2. وصّله باللاب وتأكد إنه ظاهر: `flutter devices`
3. للتجربة السريعة: `flutter run`
4. لبناء APK نهائي:
   ```bash
   flutter build apk --release
   ```
   الملف هيكون في: `build/app/outputs/flutter-apk/app-release.apk`
   انسخه لجوالك ورّكبه (فعّل "التثبيت من مصادر غير معروفة" في الإعدادات).

### بديل من غير لاب
لو مش عايز تثبت Flutter، استخدم **Codemagic** (فيه خطة مجانية) لبناء APK من كود مرفوع على GitHub مباشرة.

## هيكل المشروع

```
supabase/
  schema.sql                         # مخطط قاعدة البيانات كامل (شغّله في Supabase)
lib/
  main.dart                          # نقطة الدخول + تهيئة Supabase + دعم RTL
  theme/app_theme.dart               # الألوان والخط
  models/product.dart                # موديلات المنتج والطلب
  data/mock_data.dart                # بيانات تجريبية (لسه مستخدمة في شاشات مش متصلة بعد)
  services/
    supabase_service.dart            # الاتصال بـ Supabase (URL + anon key هنا)
    auth_service.dart                # تسجيل الدخول / إنشاء حساب / قراءة الدور
    cart_service.dart                # إدارة السلة محليًا
  screens/
    role_router_screen.dart          # يوجّه المستخدم بعد الدخول حسب دوره
    auth/
      login_screen.dart              # تسجيل دخول حقيقي عبر Supabase
      signup_screen.dart             # تسجيل حساب جديد + اختيار الدور
    customer/                        # Home + منتجات (متصلة بـ Supabase) + سلة + تأكيد
    merchant/                        # لوحة التاجر + إضافة منتج (متصلة بـ Supabase)
    marketer/                        # لوحة المسوق + تحديد سعر البيع
    courier/                         # طلبات المندوب + تفاصيل وتحصيل
```

## إيه اللي اتوصّل فعليًا بـ Supabase دلوقتي

✅ تسجيل الدخول / إنشاء حساب (auth حقيقي بأربع أدوار)
✅ عرض المنتجات للعميل - بيانات حقيقية من الجدول
✅ إضافة منتج من التاجر - بيحفظ فعليًا في القاعدة
✅ إتمام الطلب من السلة - بيحفظ order + order_items حقيقيين
✅ لوحة التاجر - منتجاته وطلباته الحقيقية
✅ لوحة المسوق - المنتجات وإجمالي العمولات الحقيقي
✅ لوحة المندوب - الطلبات المعلّقة وطلباته
✅ تأكيد التسليم من المندوب - بيحدّث حالة الطلب ويسجّل عمولة المسوق تلقائيًا (لو الطلب جاي من مسوق)

## اللي لسه محتاج شغل (خارج نطاق النسخة دي)

- **رابط مسوق حقيقي**: دلوقتي "حدد سعرك" بتاعت المسوق بترجع للوحته من غير ما تربط الرابط فعليًا بطلب العميل (يحتاج نظام روابط/أكواد إحالة + Deep Linking).
- **صور حقيقية للمنتجات**: بدل الإيموجي المؤقت (يحتاج Supabase Storage لرفع الصور).
- **نظام إشعارات فورية**: لتنبيه التاجر/المندوب بطلب جديد (يمكن استخدام Supabase Realtime).
- **مراحل وسيطة لحالة الطلب**: دلوقتي بتقفز من pending لـ delivered مباشرة عند تأكيد المندوب، من غير preparing/out_for_delivery.

## الألوان (تقريبية من sauqna.com)

| الاسم | القيمة |
|---|---|
| Primary (تركواز) | #1A9E9E |
| Navy (كحلي) | #1B2A4A |
| Gold (ذهبي) | #C99A45 |
| Background Light | #E4F5F3 → #F5FBFA |

## الخطوة الجاية المقترحة

قولّي لو حابب نبني نظام روابط المسوق الحقيقي (ربط الطلب بمسوق معيّن)، أو رفع صور المنتجات، أو أي حاجة تانية.

## تجهيز Android تلقائيًا

تمت إضافة `tools/prepare_android.sh` و `build_apk.sh` و `build_apk.bat`.
كما تمت إضافة GitHub Actions لبناء APK تلقائيًا عند تشغيل Workflow، مع تمرير Supabase عبر Secrets بدل وضع المفاتيح داخل المستودع.
